#ifdef __CLING__
#pragma cling optimize(0)
#endif
void Z_dR_Bj0()
{
//=========Macro generated from canvas: Z_dR_Bj0/Z_dR_Bj0
//=========  (Wed Mar 27 16:46:17 2024) by ROOT version 6.28/10
   TCanvas *Z_dR_Bj0 = new TCanvas("Z_dR_Bj0", "Z_dR_Bj0",0,0,600,600);
   gStyle->SetOptStat(0);
   Z_dR_Bj0->SetHighLightColor(2);
   Z_dR_Bj0->Range(-1.2,-0.07254495,6.8,0.6529045);
   Z_dR_Bj0->SetFillColor(0);
   Z_dR_Bj0->SetFillStyle(4000);
   Z_dR_Bj0->SetBorderMode(0);
   Z_dR_Bj0->SetBorderSize(2);
   Z_dR_Bj0->SetLeftMargin(0.15);
   Z_dR_Bj0->SetFrameFillStyle(1000);
   Z_dR_Bj0->SetFrameBorderMode(0);
   Z_dR_Bj0->SetFrameFillStyle(1000);
   Z_dR_Bj0->SetFrameBorderMode(0);
   
   TH1D *VH_tagOnly_Z_dR_Bj0__37 = new TH1D("VH_tagOnly_Z_dR_Bj0__37","",30,0,6);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(1,0.1237759);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(2,0.5527234);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(3,0.3862661);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(4,0.189932);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(5,0.128044);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(6,0.07469235);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(7,0.04268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(8,0.04481541);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(9,0.04481541);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(10,0.05548574);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(11,0.04268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(12,0.04694947);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(13,0.02347474);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(14,0.02987694);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(15,0.03414507);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(16,0.03414507);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(17,0.004268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(18,0.008536268);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(19,0.008536268);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(20,0.008536268);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(21,0.01067034);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(22,0.0128044);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(23,0.004268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(24,0.004268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(25,0.006402201);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(26,0.002134067);
   VH_tagOnly_Z_dR_Bj0__37->SetBinContent(28,0.002134067);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(1,0.01625257);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(2,0.03434456);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(3,0.02871094);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(4,0.02013275);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(5,0.01653041);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(6,0.01262531);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(7,0.009543838);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(8,0.009779524);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(9,0.009779524);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(10,0.01088165);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(11,0.009543838);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(12,0.01000966);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(13,0.0070779);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(14,0.007984948);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(15,0.008536268);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(16,0.008536268);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(17,0.003018027);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(18,0.004268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(19,0.004268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(20,0.004268134);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(21,0.004771919);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(22,0.005227375);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(23,0.003018027);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(24,0.003018027);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(25,0.003696313);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(26,0.002134067);
   VH_tagOnly_Z_dR_Bj0__37->SetBinError(28,0.002134067);
   VH_tagOnly_Z_dR_Bj0__37->SetEntries(903);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#000099");
   VH_tagOnly_Z_dR_Bj0__37->SetLineColor(ci);
   VH_tagOnly_Z_dR_Bj0__37->GetXaxis()->SetTitle("#DeltaR(Z,j_{1})");
   VH_tagOnly_Z_dR_Bj0__37->GetXaxis()->SetRange(1,30);
   VH_tagOnly_Z_dR_Bj0__37->GetXaxis()->SetLabelFont(42);
   VH_tagOnly_Z_dR_Bj0__37->GetXaxis()->SetTitleOffset(1);
   VH_tagOnly_Z_dR_Bj0__37->GetXaxis()->SetTitleFont(42);
   VH_tagOnly_Z_dR_Bj0__37->GetYaxis()->SetTitle("Events/0.2");
   VH_tagOnly_Z_dR_Bj0__37->GetYaxis()->SetLabelFont(42);
   VH_tagOnly_Z_dR_Bj0__37->GetYaxis()->SetLabelSize(0.05);
   VH_tagOnly_Z_dR_Bj0__37->GetYaxis()->SetTitleSize(0.057);
   VH_tagOnly_Z_dR_Bj0__37->GetYaxis()->SetTitleOffset(1.2);
   VH_tagOnly_Z_dR_Bj0__37->GetYaxis()->SetTitleFont(42);
   VH_tagOnly_Z_dR_Bj0__37->GetZaxis()->SetLabelFont(42);
   VH_tagOnly_Z_dR_Bj0__37->GetZaxis()->SetTitleOffset(1);
   VH_tagOnly_Z_dR_Bj0__37->GetZaxis()->SetTitleFont(42);
   VH_tagOnly_Z_dR_Bj0__37->Draw("hist");
   TLatex *   tex = new TLatex(0.25,0.937775,"CMS Work in Progress #sqrt{s} = 13 TeV, -- fb^{-1}");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   Z_dR_Bj0->Modified();
   Z_dR_Bj0->cd();
   Z_dR_Bj0->SetSelected(Z_dR_Bj0);
}
